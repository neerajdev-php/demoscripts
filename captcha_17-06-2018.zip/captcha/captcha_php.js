jQuery(function($){
 function get_captcha_code(){	   
	 $.get("http://nrtechwebsolution.com/captcha/Captcha.php", function(data, status){
         $('#captcha_code').html(data);
    }); 
 }	
 get_captcha_code();
	
	
	
});