<?php
session_start();
$cap = 'notEq'; // This php variable is passed to jquery variable to show alert
if (isset($_POST['Submit'])) 
{
if ($_POST['captcha'] == $_SESSION['cap_code']) 
{
// Captcha verification is Correct. Do something here!
$cap = 'Yes its same ';
} else{
	$cap = 'No its same!! ';
}
echo $cap;
unset($_SESSION['cap_code']);
}
?>


<html>
<head>
<script type="text/javascript" src="http://ajax.googleapis.com/
ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="captcha_php.js"></script>

<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>

</head>
<body>
<form action="" method="post">

<label>Enter the captcha code here</label>
<br/>
<input type="text" name="captcha" id="captcha" value=""  />

<lable>Captcha Code : </lable>
<br/>
<div id="captcha_code"></div>
<input type="submit" name="Submit" value="Submit" id="submit"/>
</form>
</body>
</html>